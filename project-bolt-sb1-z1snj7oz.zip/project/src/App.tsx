import React, { useState } from 'react';
import { Header } from './components/Header';
import { ProgressBar } from './components/ProgressBar';
import { ApiKeySetup } from './components/steps/ApiKeySetup';
import { BasicConfiguration } from './components/steps/BasicConfiguration';
import { TestApiCall } from './components/steps/TestApiCall';
import { ConfirmIntegration } from './components/steps/ConfirmIntegration';
import { GoLive } from './components/steps/GoLive';
import { Toaster } from './components/ui/sonner';

export interface OnboardingData {
  apiKey: string; // Will store "appKey:appSecret" format
  environment: 'sandbox' | 'production';
  businessProfile: {
    companyName: string;
    industry: string;
    useCase: string;
  };
  selectedModules: string[];
  testResults: {
    endpoint: string;
    success: boolean;
    response?: any;
  }[];
  isReadyToGoLive: boolean;
}

const STEPS = [
  { id: 1, title: 'Authentication', description: 'Configure your app credentials' },
  { id: 2, title: 'Configuration', description: 'Set up your business profile' },
  { id: 3, title: 'API Testing', description: 'Test your integration' },
  { id: 4, title: 'Review', description: 'Confirm your setup' },
  { id: 5, title: 'Go Live', description: 'Activate production access' }
];

function App() {
  const [currentStep, setCurrentStep] = useState(1);
  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    apiKey: '',
    environment: 'sandbox',
    businessProfile: {
      companyName: '',
      industry: '',
      useCase: ''
    },
    selectedModules: [],
    testResults: [],
    isReadyToGoLive: false
  });

  const updateOnboardingData = (updates: Partial<OnboardingData>) => {
    setOnboardingData(prev => ({ ...prev, ...updates }));
  };

  const nextStep = () => {
    if (currentStep < STEPS.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <ApiKeySetup
            data={onboardingData}
            onUpdate={updateOnboardingData}
            onNext={nextStep}
          />
        );
      case 2:
        return (
          <BasicConfiguration
            data={onboardingData}
            onUpdate={updateOnboardingData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        );
      case 3:
        return (
          <TestApiCall
            data={onboardingData}
            onUpdate={updateOnboardingData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        );
      case 4:
        return (
          <ConfirmIntegration
            data={onboardingData}
            onUpdate={updateOnboardingData}
            onNext={nextStep}
            onPrev={prevStep}
          />
        );
      case 5:
        return (
          <GoLive
            data={onboardingData}
            onUpdate={updateOnboardingData}
            onPrev={prevStep}
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <ProgressBar 
            steps={STEPS}
            currentStep={currentStep}
            completedSteps={currentStep - 1}
          />
        </div>

        <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-xl border border-white/50 overflow-hidden">
          {renderCurrentStep()}
        </div>
      </div>
      
      <Toaster />
    </div>
  );
}

export default App;