import React from 'react';
import { Check, Circle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Step {
  id: number;
  title: string;
  description: string;
}

interface ProgressBarProps {
  steps: Step[];
  currentStep: number;
  completedSteps: number;
}

export function ProgressBar({ steps, currentStep, completedSteps }: ProgressBarProps) {
  const progressPercentage = (completedSteps / steps.length) * 100;

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/50">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-900">Onboarding Progress</h2>
        <div className="text-sm text-slate-600">
          Step {currentStep} of {steps.length}
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="w-full bg-slate-200 rounded-full h-2 mb-6">
        <div 
          className="bg-gradient-to-r from-blue-500 to-indigo-600 h-2 rounded-full transition-all duration-500"
          style={{ width: `${progressPercentage}%` }}
        />
      </div>

      {/* Steps */}
      <div className="flex items-center justify-between">
        {steps.map((step, index) => {
          const isCompleted = step.id <= completedSteps;
          const isCurrent = step.id === currentStep;
          const isUpcoming = step.id > currentStep;
          
          return (
            <div key={step.id} className="flex flex-col items-center space-y-2 flex-1">
              <div className={cn(
                "flex items-center justify-center w-10 h-10 rounded-full transition-all duration-300",
                isCompleted && "bg-green-500 text-white shadow-lg shadow-green-500/25",
                isCurrent && "bg-blue-500 text-white shadow-lg shadow-blue-500/25 scale-110",
                isUpcoming && "bg-slate-200 text-slate-400"
              )}>
                {isCompleted ? (
                  <Check className="w-5 h-5" />
                ) : (
                  <Circle className="w-5 h-5" fill="currentColor" />
                )}
              </div>
              
              <div className="text-center">
                <div className={cn(
                  "font-medium text-sm",
                  isCurrent && "text-blue-600",
                  isCompleted && "text-green-600",
                  isUpcoming && "text-slate-500"
                )}>
                  {step.title}
                </div>
                <div className="text-xs text-slate-500 hidden sm:block">
                  {step.description}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}