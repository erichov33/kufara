import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import { Building, ArrowRight, ArrowLeft, Shield, CreditCard, User, FileText, Search } from 'lucide-react';
import { toast } from 'sonner';
import { OnboardingData } from '../../App';

interface BasicConfigurationProps {
  data: OnboardingData;
  onUpdate: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

const API_MODULES = [
  {
    id: 'identity-verification',
    name: 'Identity Verification',
    description: 'Comprehensive identity verification and KYC services',
    icon: User,
    popular: true
  },
  {
    id: 'credit-assessment',
    name: 'Credit Assessment',
    description: 'Credit scoring and financial risk evaluation',
    icon: CreditCard,
    popular: true
  },
  {
    id: 'fraud-detection',
    name: 'Fraud Detection',
    description: 'Real-time fraud prevention and risk monitoring',
    icon: Shield,
    popular: true
  },
  {
    id: 'document-verification',
    name: 'Document Verification',
    description: 'Automated document validation and authenticity checks',
    icon: FileText,
    popular: false
  },
  {
    id: 'background-checks',
    name: 'Background Checks',
    description: 'Comprehensive background screening services',
    icon: Search,
    popular: false
  }
];

const INDUSTRIES = [
  'Financial Services',
  'Fintech',
  'Banking',
  'Insurance',
  'Lending',
  'E-commerce',
  'Real Estate',
  'Healthcare',
  'Government',
  'Other'
];

export function BasicConfiguration({ data, onUpdate, onNext, onPrev }: BasicConfigurationProps) {
  const [businessProfile, setBusinessProfile] = useState(data.businessProfile);
  const [selectedModules, setSelectedModules] = useState<string[]>(data.selectedModules);

  const handleModuleToggle = (moduleId: string) => {
    setSelectedModules(prev => 
      prev.includes(moduleId) 
        ? prev.filter(id => id !== moduleId)
        : [...prev, moduleId]
    );
  };

  const handleNext = () => {
    if (!businessProfile.companyName.trim()) {
      toast.error('Please enter your company name');
      return;
    }

    if (!businessProfile.industry) {
      toast.error('Please select your industry');
      return;
    }

    if (selectedModules.length === 0) {
      toast.error('Please select at least one API module');
      return;
    }

    onUpdate({ businessProfile, selectedModules });
    toast.success('Configuration saved successfully!');
    onNext();
  };

  return (
    <div className="p-8">
      <div className="text-center mb-8">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mb-4">
          <Building className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Basic Configuration</h2>
        <p className="text-slate-600">
          Tell us about your business and select the AkibaOne services you need
        </p>
      </div>

      <div className="max-w-2xl mx-auto space-y-8">
        {/* Business Profile */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-900">Business Profile</h3>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="companyName">Company Name</Label>
              <Input
                id="companyName"
                placeholder="Enter your company name"
                value={businessProfile.companyName}
                onChange={(e) => setBusinessProfile(prev => ({ ...prev, companyName: e.target.value }))}
                className="h-12"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="industry">Industry</Label>
              <Select 
                value={businessProfile.industry} 
                onValueChange={(value) => setBusinessProfile(prev => ({ ...prev, industry: value }))}
              >
                <SelectTrigger className="h-12">
                  <SelectValue placeholder="Select your industry" />
                </SelectTrigger>
                <SelectContent>
                  {INDUSTRIES.map(industry => (
                    <SelectItem key={industry} value={industry}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="useCase">Primary Use Case</Label>
              <Textarea
                id="useCase"
                placeholder="Briefly describe how you plan to use AkibaOne services..."
                value={businessProfile.useCase}
                onChange={(e) => setBusinessProfile(prev => ({ ...prev, useCase: e.target.value }))}
                className="min-h-[80px]"
              />
            </div>
          </div>
        </div>

        {/* API Modules */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-slate-900">Select AkibaOne Services</h3>
          <p className="text-sm text-slate-600">Choose the services you want to integrate with</p>
          
          <div className="space-y-3">
            {API_MODULES.map(module => {
              const Icon = module.icon;
              const isSelected = selectedModules.includes(module.id);
              
              return (
                <div 
                  key={module.id}
                  className={`border rounded-lg p-4 cursor-pointer transition-all ${
                    isSelected 
                      ? 'border-blue-300 bg-blue-50' 
                      : 'border-slate-200 hover:border-slate-300'
                  }`}
                  onClick={() => handleModuleToggle(module.id)}
                >
                  <div className="flex items-start space-x-3">
                    <Checkbox 
                      checked={isSelected}
                      onChange={() => handleModuleToggle(module.id)}
                      className="mt-1"
                    />
                    <div className="flex items-center space-x-3 flex-1">
                      <div className="flex items-center justify-center w-10 h-10 bg-slate-100 rounded-lg">
                        <Icon className="w-5 h-5 text-slate-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2">
                          <span className="font-medium text-slate-900">{module.name}</span>
                          {module.popular && (
                            <span className="px-2 py-1 text-xs bg-green-100 text-green-700 rounded-full">
                              Popular
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-slate-600 mt-1">{module.description}</p>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6 border-t border-slate-200">
          <Button variant="outline" onClick={onPrev} className="flex items-center space-x-2">
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </Button>
          
          <Button 
            onClick={handleNext}
            className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700 flex items-center space-x-2"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}