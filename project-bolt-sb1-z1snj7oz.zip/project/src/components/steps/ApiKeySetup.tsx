import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Server, Key, ArrowRight, Copy, ExternalLink, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { OnboardingData } from '../../App';

interface ApiKeySetupProps {
  data: OnboardingData;
  onUpdate: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
}

export function ApiKeySetup({ data, onUpdate, onNext }: ApiKeySetupProps) {
  const [appKey, setAppKey] = useState(data.apiKey.split(':')[0] || '');
  const [appSecret, setAppSecret] = useState(data.apiKey.split(':')[1] || '');
  const [environment, setEnvironment] = useState<'sandbox' | 'production'>(data.environment);
  const [isValidating, setIsValidating] = useState(false);

  const handleNext = async () => {
    if (!appKey.trim() || !appSecret.trim()) {
      toast.error('Please enter both App Key and App Secret');
      return;
    }

    setIsValidating(true);
    
    try {
      // Simulate OAuth token request
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate token validation
      const credentials = `${appKey}:${appSecret}`;
      const encodedCredentials = btoa(credentials);
      
      // Mock token response
      const tokenResponse = {
        access_token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
        token_type: "bearer",
        expires_in: 3600,
        refresh_token: "refresh_token_here"
      };
      
      // Store the combined credentials for later use
      onUpdate({ 
        apiKey: credentials,
        environment 
      });
      
      toast.success('Authentication successful! Access token obtained.');
      onNext();
      
    } catch (error) {
      toast.error('Authentication failed. Please check your credentials.');
    } finally {
      setIsValidating(false);
    }
  };

  const copyAuthExample = () => {
    const credentials = `${appKey || 'your-app-key'}:${appSecret || 'your-app-secret'}`;
    const encodedCredentials = btoa(credentials);
    
    const snippet = `// AkibaOne Authentication Example
const credentials = '${credentials}';
const encodedCredentials = btoa(credentials);

const tokenResponse = await fetch('${environment === 'production' ? 'https://api.akibaone.com' : 'https://sandbox-api.akibaone.com'}/authorization/token', {
  method: 'POST',
  headers: {
    'Authorization': \`Basic \${encodedCredentials}\`,
    'Content-Type': 'application/x-www-form-urlencoded'
  },
  body: 'grant_type=client_credentials'
});

const { access_token } = await tokenResponse.json();

// Use the access token for API calls
const apiResponse = await fetch('${environment === 'production' ? 'https://api.akibaone.com' : 'https://sandbox-api.akibaone.com'}/api/v1/identity/verify', {
  method: 'POST',
  headers: {
    'Authorization': \`Bearer \${access_token}\`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify(payload)
});`;
    
    navigator.clipboard.writeText(snippet);
    toast.success('Authentication code example copied to clipboard!');
  };

  return (
    <div className="p-8">
      <div className="text-center mb-8">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-full flex items-center justify-center mb-4">
          <Lock className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Authentication Setup</h2>
        <p className="text-slate-600">
          Configure your AkibaOne app credentials for secure API access
        </p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="appKey" className="text-sm font-medium text-slate-700">
              App Key
            </Label>
            <div className="relative">
              <Input
                id="appKey"
                type="text"
                placeholder="Enter your app key"
                value={appKey}
                onChange={(e) => setAppKey(e.target.value)}
                className="pl-10 h-12 text-base"
              />
              <Key className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="appSecret" className="text-sm font-medium text-slate-700">
              App Secret
            </Label>
            <div className="relative">
              <Input
                id="appSecret"
                type="password"
                placeholder="Enter your app secret"
                value={appSecret}
                onChange={(e) => setAppSecret(e.target.value)}
                className="pl-10 h-12 text-base"
              />
              <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            </div>
            <div className="flex items-center justify-between">
              <p className="text-xs text-slate-500">
                Find your app credentials in the AkibaOne dashboard under App Management
              </p>
              <Button 
                variant="ghost" 
                size="sm" 
                className="text-xs"
                onClick={() => window.open('https://akibaone.com', '_blank')}
              >
                <ExternalLink className="w-3 h-3 mr-1" />
                Open Dashboard
              </Button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="environment" className="text-sm font-medium text-slate-700">
              Environment
            </Label>
            <Select value={environment} onValueChange={(value: 'sandbox' | 'production') => setEnvironment(value)}>
              <SelectTrigger className="h-12">
                <div className="flex items-center space-x-2">
                  <Server className="w-4 h-4 text-slate-400" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sandbox">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-amber-400 rounded-full"></div>
                    <span>Sandbox (Testing)</span>
                  </div>
                </SelectItem>
                <SelectItem value="production">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Production (Live)</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Authentication Flow Example */}
        <Card className="bg-slate-50 border-slate-200">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-slate-700">
                OAuth 2.0 Authentication Flow
              </CardTitle>
              <Button variant="ghost" size="sm" onClick={copyAuthExample}>
                <Copy className="w-3 h-3 mr-1" />
                Copy Code
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="text-xs text-slate-600">
                <strong>Step 1:</strong> Create Basic Authorization Header
              </div>
              <pre className="text-xs text-slate-600 bg-white p-3 rounded border overflow-x-auto">
{`const credentials = '${appKey || 'your-app-key'}:${appSecret || 'your-app-secret'}';
const encodedCredentials = btoa(credentials);`}
              </pre>
              
              <div className="text-xs text-slate-600">
                <strong>Step 2:</strong> Request Access Token
              </div>
              <pre className="text-xs text-slate-600 bg-white p-3 rounded border overflow-x-auto">
{`POST ${environment === 'production' ? 'https://api.akibaone.com' : 'https://sandbox-api.akibaone.com'}/authorization/token
Authorization: Basic \${encodedCredentials}
Content-Type: application/x-www-form-urlencoded

grant_type=client_credentials`}
              </pre>
            </div>
          </CardContent>
        </Card>

        <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
          <div className="flex items-start space-x-3">
            <Shield className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-blue-700">
              <p className="font-medium mb-1">OAuth 2.0 Client Credentials Flow</p>
              <p>AkibaOne uses industry-standard OAuth 2.0 authentication. Your app credentials are used to obtain access tokens that expire after 1 hour for enhanced security.</p>
            </div>
          </div>
        </div>

        <Button 
          onClick={handleNext} 
          disabled={isValidating || !appKey.trim() || !appSecret.trim()}
          className="w-full h-12 text-base bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800"
        >
          {isValidating ? (
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
              <span>Authenticating...</span>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <span>Authenticate & Continue</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          )}
        </Button>
      </div>
    </div>
  );
}