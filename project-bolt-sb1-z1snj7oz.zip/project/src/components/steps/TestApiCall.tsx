import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Play, ArrowRight, ArrowLeft, CheckCircle, AlertCircle, RefreshCw, Code, Lock } from 'lucide-react';
import { toast } from 'sonner';
import { OnboardingData } from '../../App';

interface TestApiCallProps {
  data: OnboardingData;
  onUpdate: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

const SAMPLE_PAYLOADS: Record<string, any> = {
  'identity-verification': {
    firstName: "John",
    lastName: "Doe",
    dateOfBirth: "1990-01-15",
    idNumber: "1234567890123",
    phoneNumber: "+1234567890",
    address: {
      street: "123 Main Street",
      city: "New York",
      state: "NY",
      postalCode: "10001",
      country: "US"
    }
  },
  'credit-assessment': {
    applicantId: "app_12345",
    personalInfo: {
      firstName: "John",
      lastName: "Doe",
      ssn: "123-45-6789",
      dateOfBirth: "1990-01-15"
    },
    requestedAmount: 50000,
    loanPurpose: "personal"
  },
  'fraud-detection': {
    transactionId: "txn_abc123",
    amount: 1500.00,
    currency: "USD",
    merchantId: "merchant_xyz",
    customerInfo: {
      customerId: "cust_12345",
      email: "john.doe@example.com",
      phoneNumber: "+1234567890"
    },
    deviceInfo: {
      ipAddress: "192.168.1.1",
      userAgent: "Mozilla/5.0...",
      deviceFingerprint: "fp_xyz789"
    }
  }
};

export function TestApiCall({ data, onUpdate, onNext, onPrev }: TestApiCallProps) {
  const [selectedEndpoint, setSelectedEndpoint] = useState('');
  const [payload, setPayload] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [testResult, setTestResult] = useState<any>(null);
  const [accessToken, setAccessToken] = useState('');

  const availableEndpoints = data.selectedModules.map(moduleId => {
    switch (moduleId) {
      case 'identity-verification':
        return { id: 'identity-verification', name: 'Identity Verification', endpoint: '/api/v1/identity/verify' };
      case 'credit-assessment':
        return { id: 'credit-assessment', name: 'Credit Assessment', endpoint: '/api/v1/credit/assess' };
      case 'fraud-detection':
        return { id: 'fraud-detection', name: 'Fraud Detection', endpoint: '/api/v1/fraud/detect' };
      case 'document-verification':
        return { id: 'document-verification', name: 'Document Verification', endpoint: '/api/v1/documents/verify' };
      case 'background-checks':
        return { id: 'background-checks', name: 'Background Checks', endpoint: '/api/v1/background/check' };
      default:
        return null;
    }
  }).filter(Boolean);

  const handleEndpointChange = (endpointId: string) => {
    setSelectedEndpoint(endpointId);
    if (SAMPLE_PAYLOADS[endpointId]) {
      setPayload(JSON.stringify(SAMPLE_PAYLOADS[endpointId], null, 2));
    }
  };

  const getAccessToken = async () => {
    const [appKey, appSecret] = data.apiKey.split(':');
    const credentials = `${appKey}:${appSecret}`;
    const encodedCredentials = btoa(credentials);
    
    // Simulate OAuth token request
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const mockToken = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFraWJhT25lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c";
    setAccessToken(mockToken);
    return mockToken;
  };

  const runTest = async () => {
    if (!selectedEndpoint) {
      toast.error('Please select an endpoint to test');
      return;
    }

    if (!payload.trim()) {
      toast.error('Please enter a test payload');
      return;
    }

    try {
      JSON.parse(payload);
    } catch {
      toast.error('Invalid JSON format in payload');
      return;
    }

    setIsLoading(true);
    
    try {
      // Step 1: Get access token
      toast.info('Obtaining access token...');
      const token = await getAccessToken();
      
      // Step 2: Make API call
      toast.info('Making API request...');
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      const mockResult = {
        endpoint: selectedEndpoint,
        success: true,
        response: generateMockResponse(selectedEndpoint),
        timestamp: new Date().toISOString(),
        accessToken: token.substring(0, 20) + '...' // Show partial token for demo
      };
      
      setTestResult(mockResult);
      
      // Update onboarding data
      const updatedTestResults = [...data.testResults];
      const existingIndex = updatedTestResults.findIndex(r => r.endpoint === selectedEndpoint);
      
      if (existingIndex >= 0) {
        updatedTestResults[existingIndex] = mockResult;
      } else {
        updatedTestResults.push(mockResult);
      }
      
      onUpdate({ testResults: updatedTestResults });
      toast.success('Test completed successfully!');
      
    } catch (error) {
      const errorResult = {
        endpoint: selectedEndpoint,
        success: false,
        response: { error: 'Authentication failed or API error' },
        timestamp: new Date().toISOString()
      };
      
      setTestResult(errorResult);
      toast.error('Test failed. Please check your credentials.');
    } finally {
      setIsLoading(false);
    }
  };

  const generateMockResponse = (endpoint: string) => {
    switch (endpoint) {
      case 'identity-verification':
        return {
          verificationId: "ver_12345",
          status: "verified",
          confidence: 0.95,
          checks: {
            identityMatch: "pass",
            documentAuthenticity: "pass",
            livenessCheck: "pass"
          },
          riskScore: 0.12
        };
      case 'credit-assessment':
        return {
          assessmentId: "assess_67890",
          creditScore: 742,
          riskGrade: "A",
          recommendation: "approve",
          factors: ["Payment history", "Credit utilization", "Length of credit history"]
        };
      case 'fraud-detection':
        return {
          transactionId: "txn_abc123",
          riskScore: 0.23,
          decision: "approve",
          riskFactors: ["Device fingerprint", "Velocity check", "Behavioral analysis"],
          recommendation: "proceed"
        };
      default:
        return { status: 'success', message: 'Test completed successfully' };
    }
  };

  const handleNext = () => {
    if (data.testResults.length === 0) {
      toast.error('Please run at least one test before continuing');
      return;
    }
    onNext();
  };

  return (
    <div className="p-8">
      <div className="text-center mb-8">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-purple-500 to-pink-600 rounded-full flex items-center justify-center mb-4">
          <Play className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Test API Integration</h2>
        <p className="text-slate-600">
          Test your AkibaOne services with OAuth 2.0 authentication
        </p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Authentication Status */}
        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <Lock className="w-5 h-5 text-blue-600" />
              <div>
                <div className="font-medium text-blue-900">OAuth 2.0 Authentication</div>
                <div className="text-sm text-blue-700">
                  {accessToken ? 'Access token obtained' : 'Will authenticate automatically during test'}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Endpoint Selection */}
        <div className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-slate-700">
              Select Service to Test
            </label>
            <Select value={selectedEndpoint} onValueChange={handleEndpointChange}>
              <SelectTrigger className="h-12">
                <SelectValue placeholder="Choose a service..." />
              </SelectTrigger>
              <SelectContent>
                {availableEndpoints.map(endpoint => (
                  <SelectItem key={endpoint.id} value={endpoint.id}>
                    <div className="flex items-center justify-between w-full">
                      <span>{endpoint.name}</span>
                      <Badge variant="outline" className="ml-2 text-xs">
                        {endpoint.endpoint}
                      </Badge>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {selectedEndpoint && (
            <div className="space-y-2">
              <label className="text-sm font-medium text-slate-700 flex items-center space-x-2">
                <Code className="w-4 h-4" />
                <span>Test Payload (JSON)</span>
              </label>
              <Textarea
                value={payload}
                onChange={(e) => setPayload(e.target.value)}
                placeholder="Enter your JSON payload here..."
                className="min-h-[200px] font-mono text-sm"
              />
            </div>
          )}

          <Button
            onClick={runTest}
            disabled={!selectedEndpoint || !payload.trim() || isLoading}
            className="w-full h-12 bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700"
          >
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Testing API...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Play className="w-4 h-4" />
                <span>Run Test with OAuth</span>
              </div>
            )}
          </Button>
        </div>

        {/* Test Results */}
        {testResult && (
          <Card className={`border-2 ${testResult.success ? 'border-green-200 bg-green-50' : 'border-red-200 bg-red-50'}`}>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                {testResult.success ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : (
                  <AlertCircle className="w-5 h-5 text-red-500" />
                )}
                <span>Test Result</span>
              </CardTitle>
              <CardDescription>
                {availableEndpoints.find(e => e.id === testResult.endpoint)?.name}
                {testResult.accessToken && (
                  <div className="text-xs text-slate-500 mt-1">
                    Access Token: {testResult.accessToken}
                  </div>
                )}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="bg-white rounded-lg p-4 border">
                <pre className="text-sm text-slate-700 overflow-x-auto">
                  {JSON.stringify(testResult.response, null, 2)}
                </pre>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Previous Test Results */}
        {data.testResults.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-medium text-slate-700">Previous Test Results</h3>
            {data.testResults.map((result, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                <div className="flex items-center space-x-3">
                  {result.success ? (
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-500" />
                  )}
                  <span className="text-sm font-medium">
                    {availableEndpoints.find(e => e.id === result.endpoint)?.name}
                  </span>
                </div>
                <Badge variant={result.success ? 'default' : 'destructive'}>
                  {result.success ? 'Passed' : 'Failed'}
                </Badge>
              </div>
            ))}
          </div>
        )}

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6 border-t border-slate-200">
          <Button variant="outline" onClick={onPrev} className="flex items-center space-x-2">
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </Button>
          
          <Button 
            onClick={handleNext}
            disabled={data.testResults.length === 0}
            className="bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-600 hover:to-pink-700 flex items-center space-x-2"
          >
            <span>Continue</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}