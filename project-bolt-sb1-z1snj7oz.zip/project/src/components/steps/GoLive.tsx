import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Rocket, ArrowLeft, CheckCircle, ExternalLink, Mail, Calendar, Sparkles, Users } from 'lucide-react';
import { toast } from 'sonner';
import { OnboardingData } from '../../App';

interface GoLiveProps {
  data: OnboardingData;
  onUpdate: (updates: Partial<OnboardingData>) => void;
  onPrev: () => void;
}

export function GoLive({ data, onUpdate, onPrev }: GoLiveProps) {
  const [isActivating, setIsActivating] = useState(false);
  const [isActivated, setIsActivated] = useState(false);

  const handleGoLive = async () => {
    setIsActivating(true);
    
    // Simulate activation process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    // Send notification to internal team (simulated)
    const notificationData = {
      clientId: 'client_' + Date.now(),
      companyName: data.businessProfile.companyName,
      industry: data.businessProfile.industry,
      selectedModules: data.selectedModules,
      testResults: data.testResults,
      timestamp: new Date().toISOString(),
      environment: data.environment
    };
    
    console.log('AkibaOne internal notification sent:', notificationData);
    
    setIsActivated(true);
    setIsActivating(false);
    toast.success('🎉 Congratulations! Your AkibaOne integration is now live!');
  };

  if (isActivated) {
    return (
      <div className="p-8">
        <div className="text-center mb-8">
          <div className="mx-auto w-20 h-20 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mb-6">
            <Sparkles className="w-10 h-10 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-slate-900 mb-2">🎉 You're Live!</h2>
          <p className="text-lg text-slate-600">
            Your AkibaOne integration is now active and ready for production use
          </p>
        </div>

        <div className="max-w-2xl mx-auto space-y-6">
          <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-6">
              <div className="text-center space-y-4">
                <CheckCircle className="w-16 h-16 text-green-500 mx-auto" />
                <div>
                  <h3 className="text-xl font-semibold text-green-900 mb-2">Integration Complete</h3>
                  <p className="text-green-700">
                    Your production environment is now configured and ready to process live requests through AkibaOne's platform.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Mail className="w-5 h-5 text-blue-500" />
                  <span>Support</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-3">
                  Need help? Our technical team is here to support you.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.open('https://akibaone.com/contact', '_blank')}
                >
                  <ExternalLink className="w-3 h-3 mr-1" />
                  Contact Support
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Users className="w-5 h-5 text-purple-500" />
                  <span>Account Manager</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-slate-600 mb-3">
                  Schedule a call with your dedicated account manager.
                </p>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.open('https://akibaone.com/schedule', '_blank')}
                >
                  <Calendar className="w-3 h-3 mr-1" />
                  Schedule Call
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Integration Summary</CardTitle>
              <CardDescription>Your completed AkibaOne setup</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Company:</span>
                <span className="font-medium">{data.businessProfile.companyName}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Industry:</span>
                <span className="font-medium">{data.businessProfile.industry}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Environment:</span>
                <Badge variant="outline">{data.environment}</Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Services Enabled:</span>
                <span className="font-medium">{data.selectedModules.length} services</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-slate-600">Tests Passed:</span>
                <span className="font-medium text-green-600">
                  {data.testResults.filter(t => t.success).length}/{data.testResults.length}
                </span>
              </div>
            </CardContent>
          </Card>

          <div className="text-center pt-4">
            <p className="text-sm text-slate-500">
              Thank you for choosing AkibaOne. We're excited to see what you build with our platform!
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8">
      <div className="text-center mb-8">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mb-4">
          <Rocket className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Ready to Go Live</h2>
        <p className="text-slate-600">
          Activate your production environment and start processing live requests with AkibaOne
        </p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Pre-flight Checklist */}
        <Card>
          <CardHeader>
            <CardTitle>Pre-flight Checklist</CardTitle>
            <CardDescription>Everything looks good for production</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-sm">API key configured and validated</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-sm">Business profile completed</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-sm">AkibaOne services selected and configured</span>
            </div>
            <div className="flex items-center space-x-3">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-sm">Integration tests passed successfully</span>
            </div>
          </CardContent>
        </Card>

        {/* What Happens Next */}
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">What happens when you go live?</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3 text-sm text-blue-800">
            <div className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>Your production environment will be activated immediately</span>
            </div>
            <div className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>Our technical team will be notified and will monitor your initial requests</span>
            </div>
            <div className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>You'll receive confirmation and next steps via email</span>
            </div>
            <div className="flex items-start space-x-2">
              <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
              <span>24/7 technical support will be available for any questions</span>
            </div>
          </CardContent>
        </Card>

        {/* Go Live Button */}
        <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-6 text-center">
            <h3 className="text-lg font-semibold text-slate-900 mb-2">Ready to Launch?</h3>
            <p className="text-sm text-slate-600 mb-4">
              Click the button below to activate your AkibaOne production environment
            </p>
            
            <Button
              onClick={handleGoLive}
              disabled={isActivating}
              className="w-full h-12 text-base bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-600 hover:to-red-700"
            >
              {isActivating ? (
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                  <span>Activating Production...</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Rocket className="w-5 h-5" />
                  <span>Go Live with AkibaOne!</span>
                </div>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6 border-t border-slate-200">
          <Button variant="outline" onClick={onPrev} className="flex items-center space-x-2">
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </Button>
          
          <div className="text-sm text-slate-500">
            Step 5 of 5 - Final step!
          </div>
        </div>
      </div>
    </div>
  );
}