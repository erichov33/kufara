import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, ArrowRight, ArrowLeft, Key, Building, TestTube, AlertTriangle } from 'lucide-react';
import { OnboardingData } from '../../App';

interface ConfirmIntegrationProps {
  data: OnboardingData;
  onUpdate: (updates: Partial<OnboardingData>) => void;
  onNext: () => void;
  onPrev: () => void;
}

export function ConfirmIntegration({ data, onUpdate, onNext, onPrev }: ConfirmIntegrationProps) {
  const successfulTests = data.testResults.filter(test => test.success);
  const failedTests = data.testResults.filter(test => !test.success);
  const isReadyToGoLive = successfulTests.length > 0 && failedTests.length === 0;

  const handleConfirm = () => {
    onUpdate({ isReadyToGoLive });
    onNext();
  };

  return (
    <div className="p-8">
      <div className="text-center mb-8">
        <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mb-4">
          <CheckCircle className="w-8 h-8 text-white" />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Confirm Integration</h2>
        <p className="text-slate-600">
          Review your setup and confirm you're ready to proceed
        </p>
      </div>

      <div className="max-w-2xl mx-auto space-y-6">
        {/* Setup Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Key className="w-8 h-8 text-blue-600" />
                <div>
                  <div className="font-medium text-blue-900">API Key</div>
                  <div className="text-sm text-blue-700">
                    {data.environment === 'sandbox' ? 'Sandbox' : 'Production'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-green-50 border-green-200">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <Building className="w-8 h-8 text-green-600" />
                <div>
                  <div className="font-medium text-green-900">Profile</div>
                  <div className="text-sm text-green-700">
                    {data.businessProfile.companyName}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-purple-50 border-purple-200">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <TestTube className="w-8 h-8 text-purple-600" />
                <div>
                  <div className="font-medium text-purple-900">Tests</div>
                  <div className="text-sm text-purple-700">
                    {successfulTests.length} passed
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Configuration Details */}
        <Card>
          <CardHeader>
            <CardTitle>Configuration Summary</CardTitle>
            <CardDescription>Review your integration setup</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="text-sm font-medium text-slate-700 mb-2">Business Profile</div>
              <div className="bg-slate-50 rounded-lg p-3 space-y-1">
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Company:</span>
                  <span className="text-sm font-medium">{data.businessProfile.companyName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-slate-600">Industry:</span>
                  <span className="text-sm font-medium">{data.businessProfile.industry}</span>
                </div>
              </div>
            </div>

            <div>
              <div className="text-sm font-medium text-slate-700 mb-2">Selected API Modules</div>
              <div className="flex flex-wrap gap-2">
                {data.selectedModules.map(moduleId => (
                  <Badge key={moduleId} variant="secondary">
                    {moduleId === 'safps' && 'SAFPS Fraud Detection'}
                    {moduleId === 'credit-score' && 'Credit Score Analysis'}
                    {moduleId === 'identity-verify' && 'Identity Verification'}
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <div className="text-sm font-medium text-slate-700 mb-2">Test Results</div>
              <div className="space-y-2">
                {data.testResults.map((test, index) => (
                  <div key={index} className="flex items-center justify-between p-2 bg-slate-50 rounded">
                    <span className="text-sm">
                      {test.endpoint === 'safps' && 'SAFPS Fraud Detection'}
                      {test.endpoint === 'credit-score' && 'Credit Score Analysis'}
                      {test.endpoint === 'identity-verify' && 'Identity Verification'}
                    </span>
                    <Badge variant={test.success ? 'default' : 'destructive'}>
                      {test.success ? 'Passed' : 'Failed'}
                    </Badge>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Readiness Status */}
        <Card className={isReadyToGoLive ? 'bg-green-50 border-green-200' : 'bg-amber-50 border-amber-200'}>
          <CardContent className="p-4">
            <div className="flex items-start space-x-3">
              {isReadyToGoLive ? (
                <CheckCircle className="w-6 h-6 text-green-500 mt-0.5" />
              ) : (
                <AlertTriangle className="w-6 h-6 text-amber-500 mt-0.5" />
              )}
              <div>
                <div className={`font-medium ${isReadyToGoLive ? 'text-green-900' : 'text-amber-900'}`}>
                  {isReadyToGoLive ? 'Ready to Go Live!' : 'Action Required'}
                </div>
                <div className={`text-sm ${isReadyToGoLive ? 'text-green-700' : 'text-amber-700'}`}>
                  {isReadyToGoLive 
                    ? 'Your integration has been successfully tested and is ready for production.'
                    : 'Please ensure all tests pass before proceeding to go live.'
                  }
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between pt-6 border-t border-slate-200">
          <Button variant="outline" onClick={onPrev} className="flex items-center space-x-2">
            <ArrowLeft className="w-4 h-4" />
            <span>Back</span>
          </Button>
          
          <Button 
            onClick={handleConfirm}
            className="bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 flex items-center space-x-2"
          >
            <span>Confirm & Continue</span>
            <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}