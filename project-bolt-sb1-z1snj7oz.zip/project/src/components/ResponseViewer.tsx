import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ApiResponse } from './TestingDashboard';
import { CheckCircle, XCircle, Clock, Code, Eye, Activity } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ResponseViewerProps {
  response: ApiResponse | null;
  isLoading: boolean;
}

export function ResponseViewer({ response, isLoading }: ResponseViewerProps) {
  if (isLoading) {
    return (
      <Card className="border-0 shadow-lg">
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center space-y-4">
            <div className="w-8 h-8 border-2 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mx-auto"></div>
            <p className="text-slate-600">Testing endpoint...</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!response) {
    return (
      <Card className="border-0 shadow-lg">
        <CardContent className="flex items-center justify-center h-64">
          <div className="text-center space-y-4">
            <Activity className="w-12 h-12 text-slate-300 mx-auto" />
            <div>
              <p className="text-slate-600 font-medium">No response yet</p>
              <p className="text-sm text-slate-500">Run a test to see the response</p>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const isSuccess = response.status >= 200 && response.status < 300;
  const statusColor = isSuccess ? 'text-green-600' : 'text-red-600';
  const statusBg = isSuccess ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200';

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center space-x-2">
              {isSuccess ? (
                <CheckCircle className="w-5 h-5 text-green-500" />
              ) : (
                <XCircle className="w-5 h-5 text-red-500" />
              )}
              <span>Response</span>
            </CardTitle>
            <CardDescription>
              {response.endpoint} • {response.duration}ms
            </CardDescription>
          </div>
          <Badge className={cn(statusBg, statusColor)}>
            {response.status}
          </Badge>
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs defaultValue="pretty" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="pretty" className="flex items-center space-x-1">
              <Eye className="w-3 h-3" />
              <span>Pretty</span>
            </TabsTrigger>
            <TabsTrigger value="raw" className="flex items-center space-x-1">
              <Code className="w-3 h-3" />
              <span>Raw</span>
            </TabsTrigger>
            <TabsTrigger value="headers" className="flex items-center space-x-1">
              <Clock className="w-3 h-3" />
              <span>Headers</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="pretty" className="mt-4">
            <div className="space-y-4">
              {response.endpoint === '/credit-score' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="text-lg font-semibold text-slate-900 mb-1">
                      Credit Score
                    </div>
                    <div className="text-3xl font-bold text-blue-600">
                      {response.data.creditScore}
                    </div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="text-lg font-semibold text-slate-900 mb-1">
                      Risk Level
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      {response.data.riskLevel}
                    </Badge>
                  </div>
                </div>
              )}
              
              {response.endpoint === '/safps' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="text-lg font-semibold text-slate-900 mb-1">
                      Fraud Score
                    </div>
                    <div className="text-3xl font-bold text-green-600">
                      {(response.data.fraudScore * 100).toFixed(1)}%
                    </div>
                  </div>
                  <div className="bg-slate-50 rounded-lg p-4">
                    <div className="text-lg font-semibold text-slate-900 mb-1">
                      Decision
                    </div>
                    <Badge className="bg-green-100 text-green-800">
                      {response.data.decision}
                    </Badge>
                  </div>
                </div>
              )}
              
              <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
                <pre className="text-sm text-slate-100">
                  {JSON.stringify(response.data, null, 2)}
                </pre>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="raw" className="mt-4">
            <div className="bg-slate-900 rounded-lg p-4 overflow-x-auto">
              <pre className="text-sm text-slate-100">
                {JSON.stringify(response.data, null, 2)}
              </pre>
            </div>
          </TabsContent>
          
          <TabsContent value="headers" className="mt-4">
            <div className="space-y-2">
              {Object.entries(response.headers).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between py-2 border-b border-slate-100 last:border-0">
                  <span className="text-sm font-medium text-slate-600">{key}</span>
                  <span className="text-sm text-slate-900 font-mono">{value}</span>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}