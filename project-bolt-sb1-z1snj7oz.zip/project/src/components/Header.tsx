import React from 'react';
import { Shield, Zap } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-white/90 backdrop-blur-sm border-b border-slate-200 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4 max-w-4xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-10 h-10 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-lg">
              <Shield className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-slate-900">AkibaOne Developer Portal</h1>
              <p className="text-sm text-slate-600">Guided API Integration & Testing</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2 text-sm text-slate-600">
              <Zap className="w-4 h-4 text-amber-500" />
              <span>Quick Setup</span>
            </div>
            <a 
              href="https://akibadigital.com/developer" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-sm text-blue-600 hover:text-blue-700 font-medium"
            >
              API Docs
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}