import React from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Circle, Shield, CreditCard, User } from 'lucide-react';

interface EndpointSelectorProps {
  selectedEndpoint: string;
  onEndpointChange: (endpoint: string) => void;
  completedTests: string[];
}

const endpoints = [
  {
    value: '/credit-score',
    label: 'Credit Score Analysis',
    description: 'Analyze creditworthiness and risk factors',
    method: 'POST',
    icon: CreditCard,
    category: 'Financial'
  },
  {
    value: '/safps',
    label: 'Fraud Detection',
    description: 'Real-time fraud and risk assessment',
    method: 'POST',
    icon: Shield,
    category: 'Security'
  },
  {
    value: '/identity-verify',
    label: 'Identity Verification',
    description: 'Document and biometric verification',
    method: 'POST',
    icon: User,
    category: 'Identity'
  }
];

export function EndpointSelector({ selectedEndpoint, onEndpointChange, completedTests }: EndpointSelectorProps) {
  return (
    <div className="space-y-4">
      <div>
        <label className="text-sm font-medium text-slate-700 mb-2 block">
          Select API Endpoint
        </label>
        <Select value={selectedEndpoint} onValueChange={onEndpointChange}>
          <SelectTrigger className="h-12">
            <SelectValue placeholder="Choose an endpoint to test..." />
          </SelectTrigger>
          <SelectContent>
            {endpoints.map((endpoint) => {
              const Icon = endpoint.icon;
              const isCompleted = completedTests.includes(endpoint.value);
              
              return (
                <SelectItem key={endpoint.value} value={endpoint.value} className="p-4">
                  <div className="flex items-center space-x-3 w-full">
                    <div className="flex items-center justify-center w-8 h-8 bg-slate-100 rounded-lg">
                      <Icon className="w-4 h-4 text-slate-600" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="font-medium text-slate-900">{endpoint.label}</span>
                        <Badge variant="outline" className="text-xs">
                          {endpoint.method}
                        </Badge>
                        {isCompleted && (
                          <CheckCircle className="w-4 h-4 text-green-500" />
                        )}
                      </div>
                      <p className="text-xs text-slate-500">{endpoint.description}</p>
                    </div>
                  </div>
                </SelectItem>
              );
            })}
          </SelectContent>
        </Select>
      </div>

      {selectedEndpoint && (
        <div className="bg-slate-50 rounded-lg p-4">
          <div className="flex items-center space-x-2 mb-2">
            <div className="flex items-center space-x-1">
              {completedTests.includes(selectedEndpoint) ? (
                <CheckCircle className="w-4 h-4 text-green-500" />
              ) : (
                <Circle className="w-4 h-4 text-slate-400" />
              )}
              <span className="text-sm font-medium text-slate-700">
                {endpoints.find(e => e.value === selectedEndpoint)?.label}
              </span>
            </div>
            <Badge variant="secondary" className="text-xs">
              {endpoints.find(e => e.value === selectedEndpoint)?.category}
            </Badge>
          </div>
          <p className="text-sm text-slate-600">
            {endpoints.find(e => e.value === selectedEndpoint)?.description}
          </p>
        </div>
      )}
    </div>
  );
}