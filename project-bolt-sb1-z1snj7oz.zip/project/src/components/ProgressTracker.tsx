import React from 'react';
import { Check, Play, Lock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface Step {
  id: number;
  title: string;
  description: string;
}

interface ProgressTrackerProps {
  steps: Step[];
  currentStep: number;
  completedTests: string[];
}

export function ProgressTracker({ steps, currentStep, completedTests }: ProgressTrackerProps) {
  const getStepStatus = (stepId: number) => {
    if (stepId < currentStep) return 'completed';
    if (stepId === currentStep) return 'active';
    return 'pending';
  };

  const getStepIcon = (stepId: number) => {
    const status = getStepStatus(stepId);
    switch (status) {
      case 'completed':
        return <Check className="w-5 h-5 text-white" />;
      case 'active':
        return <Play className="w-5 h-5 text-white" />;
      default:
        return <Lock className="w-5 h-5 text-slate-400" />;
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm rounded-2xl p-6 shadow-lg border border-white/50">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-lg font-semibold text-slate-900">Onboarding Progress</h2>
        <div className="flex items-center space-x-2 text-sm text-slate-600">
          <span className="font-medium">{completedTests.length}</span>
          <span>endpoints tested</span>
        </div>
      </div>
      
      <div className="flex items-center space-x-4">
        {steps.map((step, index) => {
          const status = getStepStatus(step.id);
          const isLast = index === steps.length - 1;
          
          return (
            <React.Fragment key={step.id}>
              <div className="flex flex-col items-center space-y-2">
                <div className={cn(
                  "flex items-center justify-center w-12 h-12 rounded-full transition-all duration-300",
                  status === 'completed' && "bg-green-500 shadow-lg shadow-green-500/25",
                  status === 'active' && "bg-blue-500 shadow-lg shadow-blue-500/25 scale-110",
                  status === 'pending' && "bg-slate-200"
                )}>
                  {getStepIcon(step.id)}
                </div>
                <div className="text-center">
                  <div className={cn(
                    "font-medium text-sm",
                    status === 'active' && "text-blue-600",
                    status === 'completed' && "text-green-600",
                    status === 'pending' && "text-slate-500"
                  )}>
                    {step.title}
                  </div>
                  <div className="text-xs text-slate-500">
                    {step.description}
                  </div>
                </div>
              </div>
              
              {!isLast && (
                <div className={cn(
                  "flex-1 h-0.5 transition-colors duration-300",
                  step.id < currentStep ? "bg-green-500" : "bg-slate-200"
                )} />
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}