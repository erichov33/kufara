import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Play, RefreshCw, Code, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

interface PayloadEditorProps {
  endpoint: string;
  onTestRequest: (endpoint: string, payload: any) => void;
  isLoading: boolean;
}

const samplePayloads: Record<string, any> = {
  '/credit-score': {
    userId: "user_12345",
    applicantInfo: {
      firstName: "John",
      lastName: "Doe",
      ssn: "123-45-6789",
      dateOfBirth: "1990-01-15",
      address: {
        street: "123 Main St",
        city: "New York",
        state: "NY",
        zipCode: "10001"
      }
    },
    requestType: "full_report"
  },
  '/safps': {
    transactionId: "txn_abc123",
    amount: 250.00,
    currency: "USD",
    userDevice: {
      ipAddress: "192.168.1.1",
      userAgent: "Mozilla/5.0...",
      deviceFingerprint: "fp_xyz789"
    },
    userBehavior: {
      sessionDuration: 120,
      clickPattern: "normal",
      typingSpeed: "average"
    }
  },
  '/identity-verify': {
    documentType: "passport",
    documentImage: "base64_encoded_image...",
    selfieImage: "base64_encoded_selfie...",
    metadata: {
      deviceInfo: "iPhone 12",
      location: "New York, NY",
      timestamp: "2024-01-15T10:30:00Z"
    }
  }
};

export function PayloadEditor({ endpoint, onTestRequest, isLoading }: PayloadEditorProps) {
  const [payload, setPayload] = useState('');
  const [isValidJson, setIsValidJson] = useState(true);

  useEffect(() => {
    if (endpoint && samplePayloads[endpoint]) {
      setPayload(JSON.stringify(samplePayloads[endpoint], null, 2));
      setIsValidJson(true);
    }
  }, [endpoint]);

  const validateJson = (value: string) => {
    try {
      JSON.parse(value);
      setIsValidJson(true);
    } catch {
      setIsValidJson(false);
    }
  };

  const handlePayloadChange = (value: string) => {
    setPayload(value);
    if (value.trim()) {
      validateJson(value);
    } else {
      setIsValidJson(true);
    }
  };

  const handleGenerateSample = () => {
    if (samplePayloads[endpoint]) {
      setPayload(JSON.stringify(samplePayloads[endpoint], null, 2));
      setIsValidJson(true);
      toast.success('Sample payload generated');
    }
  };

  const handleTestRequest = () => {
    if (!payload.trim()) {
      toast.error('Please enter a payload');
      return;
    }

    if (!isValidJson) {
      toast.error('Please fix JSON syntax errors');
      return;
    }

    try {
      const parsedPayload = JSON.parse(payload);
      onTestRequest(endpoint, parsedPayload);
      toast.success('Test request sent!');
    } catch (error) {
      toast.error('Invalid JSON format');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Code className="w-4 h-4 text-slate-600" />
          <label className="text-sm font-medium text-slate-700">
            Request Payload
          </label>
          {!isValidJson && (
            <Badge variant="destructive" className="text-xs">
              Invalid JSON
            </Badge>
          )}
        </div>
        
        <Button
          variant="outline"
          size="sm"
          onClick={handleGenerateSample}
          className="text-xs"
        >
          <Sparkles className="w-3 h-3 mr-1" />
          Generate Sample
        </Button>
      </div>

      <div className="relative">
        <Textarea
          value={payload}
          onChange={(e) => handlePayloadChange(e.target.value)}
          placeholder="Enter your JSON payload here..."
          className={`min-h-[200px] font-mono text-sm ${
            !isValidJson ? 'border-red-300 focus:border-red-500' : ''
          }`}
        />
        {!isValidJson && (
          <div className="absolute bottom-2 right-2">
            <Badge variant="destructive" className="text-xs">
              Syntax Error
            </Badge>
          </div>
        )}
      </div>

      <div className="flex items-center justify-between pt-2">
        <div className="text-xs text-slate-500">
          {payload.length} characters • JSON format required
        </div>
        
        <Button
          onClick={handleTestRequest}
          disabled={isLoading || !payload.trim() || !isValidJson}
          className="bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
        >
          {isLoading ? (
            <div className="flex items-center space-x-2">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span>Testing...</span>
            </div>
          ) : (
            <div className="flex items-center space-x-2">
              <Play className="w-4 h-4" />
              <span>Run Test</span>
            </div>
          )}
        </Button>
      </div>
    </div>
  );
}