import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Shield, Server, Key, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

interface ConnectionStepProps {
  onConnect: (apiKey: string, environment: 'sandbox' | 'production') => void;
}

export function ConnectionStep({ onConnect }: ConnectionStepProps) {
  const [apiKey, setApiKey] = useState('');
  const [environment, setEnvironment] = useState<'sandbox' | 'production'>('sandbox');
  const [isValidating, setIsValidating] = useState(false);

  const handleConnect = async () => {
    if (!apiKey.trim()) {
      toast.error('Please enter your API key');
      return;
    }

    setIsValidating(true);
    
    // Simulate API key validation
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    if (apiKey.startsWith('ak_') || apiKey.startsWith('test_')) {
      toast.success('API key validated successfully!');
      onConnect(apiKey, environment);
    } else {
      toast.error('Invalid API key format. Keys should start with "ak_" or "test_"');
    }
    
    setIsValidating(false);
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-slate-900 mb-4">Connect Your API</h2>
        <p className="text-lg text-slate-600">
          Let's start by connecting your Akiba API credentials to begin testing
        </p>
      </div>

      <Card className="border-0 shadow-xl bg-white/80 backdrop-blur-sm">
        <CardHeader className="text-center pb-6">
          <div className="mx-auto w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-full flex items-center justify-center mb-4">
            <Key className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-xl">API Configuration</CardTitle>
          <CardDescription>
            Enter your API credentials to get started with testing
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="apiKey" className="text-sm font-medium text-slate-700">
              API Key
            </Label>
            <div className="relative">
              <Input
                id="apiKey"
                type="password"
                placeholder="ak_live_... or test_..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="pl-10 h-12 text-base"
              />
              <Shield className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-slate-400" />
            </div>
            <p className="text-xs text-slate-500">
              Find your API key in the Akiba dashboard under "Developers" → "API Keys"
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="environment" className="text-sm font-medium text-slate-700">
              Environment
            </Label>
            <Select value={environment} onValueChange={(value: 'sandbox' | 'production') => setEnvironment(value)}>
              <SelectTrigger className="h-12">
                <div className="flex items-center space-x-2">
                  <Server className="w-4 h-4 text-slate-400" />
                  <SelectValue />
                </div>
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sandbox">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-amber-400 rounded-full"></div>
                    <span>Sandbox (Testing)</span>
                  </div>
                </SelectItem>
                <SelectItem value="production">
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Production (Live)</span>
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="bg-slate-50 rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <Shield className="w-5 h-5 text-blue-500 mt-0.5 flex-shrink-0" />
              <div className="text-sm text-slate-600">
                <p className="font-medium text-slate-700 mb-1">Security Notice</p>
                <p>Your API key is used only for testing and is not stored permanently. We recommend using sandbox credentials for initial testing.</p>
              </div>
            </div>
          </div>

          <Button 
            onClick={handleConnect} 
            disabled={isValidating}
            className="w-full h-12 text-base bg-gradient-to-r from-blue-500 to-indigo-600 hover:from-blue-600 hover:to-indigo-700 transition-all duration-200"
          >
            {isValidating ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                <span>Validating...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <span>Connect & Continue</span>
                <ArrowRight className="w-4 h-4" />
              </div>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}