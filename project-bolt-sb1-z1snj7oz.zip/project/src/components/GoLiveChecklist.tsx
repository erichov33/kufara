import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Circle, Rocket, Trophy, Target } from 'lucide-react';
import { toast } from 'sonner';

interface GoLiveChecklistProps {
  completedTests: string[];
  onAdvanceStep: () => void;
}

const checklistItems = [
  {
    id: 'credit-score',
    title: 'Test Credit Score API',
    description: 'Validate credit scoring functionality',
    endpoint: '/credit-score'
  },
  {
    id: 'fraud-detection',
    title: 'Test Fraud Detection',
    description: 'Verify fraud prevention capabilities',
    endpoint: '/safps'
  },
  {
    id: 'identity-verify',
    title: 'Test Identity Verification',
    description: 'Confirm identity verification process',
    endpoint: '/identity-verify'
  }
];

export function GoLiveChecklist({ completedTests, onAdvanceStep }: GoLiveChecklistProps) {
  const completedCount = checklistItems.filter(item => 
    completedTests.includes(item.endpoint)
  ).length;
  
  const isReadyToGoLive = completedCount >= 2; // At least 2 tests completed
  const progressPercentage = (completedCount / checklistItems.length) * 100;

  const handleGoLive = () => {
    if (isReadyToGoLive) {
      toast.success('Congratulations! You\'re ready to go live!');
      onAdvanceStep();
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Target className="w-5 h-5 text-green-500" />
            <span>Go-Live Checklist</span>
          </CardTitle>
          <CardDescription>
            Complete these tests to prepare for production
          </CardDescription>
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between text-sm">
            <span className="text-slate-600">Progress</span>
            <span className="font-medium text-slate-900">
              {completedCount}/{checklistItems.length} completed
            </span>
          </div>
          
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div 
              className="bg-gradient-to-r from-green-500 to-emerald-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progressPercentage}%` }}
            ></div>
          </div>

          <div className="space-y-3 pt-2">
            {checklistItems.map((item) => {
              const isCompleted = completedTests.includes(item.endpoint);
              
              return (
                <div key={item.id} className="flex items-start space-x-3 p-3 bg-slate-50 rounded-lg">
                  {isCompleted ? (
                    <CheckCircle className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                  ) : (
                    <Circle className="w-5 h-5 text-slate-400 mt-0.5 flex-shrink-0" />
                  )}
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <span className={`text-sm font-medium ${
                        isCompleted ? 'text-green-700' : 'text-slate-700'
                      }`}>
                        {item.title}
                      </span>
                      {isCompleted && (
                        <Badge className="bg-green-100 text-green-800 text-xs">
                          Completed
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-slate-500">{item.description}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-200">
            {isReadyToGoLive ? (
              <Button 
                onClick={handleGoLive}
                className="w-full bg-gradient-to-r from-green-500 to-emerald-600 hover:from-green-600 hover:to-emerald-700"
              >
                <div className="flex items-center space-x-2">
                  <Rocket className="w-4 h-4" />
                  <span>Ready to Go Live!</span>
                </div>
              </Button>
            ) : (
              <div className="text-center">
                <p className="text-sm text-slate-600 mb-2">
                  Complete at least 2 tests to unlock go-live readiness
                </p>
                <Button disabled variant="outline" className="w-full">
                  <div className="flex items-center space-x-2">
                    <Circle className="w-4 h-4" />
                    <span>Complete More Tests</span>
                  </div>
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {completedCount > 0 && (
        <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-indigo-50">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <div className="flex items-center justify-center w-10 h-10 bg-blue-100 rounded-full">
                <Trophy className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="font-medium text-blue-900">Great Progress!</div>
                <div className="text-sm text-blue-700">
                  You've completed {completedCount} test{completedCount !== 1 ? 's' : ''}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}