import React, { useState } from 'react';
import { TestSession } from '../App';
import { EndpointSelector } from './EndpointSelector';
import { PayloadEditor } from './PayloadEditor';
import { ResponseViewer } from './ResponseViewer';
import { GoLiveChecklist } from './GoLiveChecklist';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { TestTube, CheckCircle, Play } from 'lucide-react';

interface TestingDashboardProps {
  session: TestSession;
  onTestComplete: (endpoint: string) => void;
  onAdvanceStep: () => void;
}

export interface ApiResponse {
  status: number;
  data: any;
  headers: Record<string, string>;
  duration: number;
  endpoint: string;
}

export function TestingDashboard({ session, onTestComplete, onAdvanceStep }: TestingDashboardProps) {
  const [selectedEndpoint, setSelectedEndpoint] = useState('');
  const [response, setResponse] = useState<ApiResponse | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleTestRequest = async (endpoint: string, payload: any) => {
    setIsLoading(true);
    const startTime = Date.now();
    
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 1000));
      
      const mockResponse: ApiResponse = {
        status: 200,
        data: generateMockResponse(endpoint, payload),
        headers: {
          'content-type': 'application/json',
          'x-response-time': `${Date.now() - startTime}ms`,
          'x-api-version': '2.1.0'
        },
        duration: Date.now() - startTime,
        endpoint
      };
      
      setResponse(mockResponse);
      onTestComplete(endpoint);
    } catch (error) {
      setResponse({
        status: 500,
        data: { error: 'Internal server error' },
        headers: {},
        duration: Date.now() - startTime,
        endpoint
      });
    } finally {
      setIsLoading(false);
    }
  };

  const generateMockResponse = (endpoint: string, payload: any) => {
    switch (endpoint) {
      case '/credit-score':
        return {
          creditScore: 742,
          riskLevel: 'LOW',
          factors: ['Payment history', 'Credit utilization', 'Length of credit history'],
          recommendations: ['Continue making on-time payments', 'Keep credit utilization below 30%']
        };
      case '/safps':
        return {
          fraudScore: 0.23,
          riskLevel: 'LOW',
          checks: {
            deviceFingerprint: 'PASS',
            velocityCheck: 'PASS',
            behaviorAnalysis: 'PASS'
          },
          decision: 'APPROVED'
        };
      case '/identity-verify':
        return {
          verified: true,
          confidence: 0.94,
          checks: {
            documentVerification: 'PASS',
            faceMatch: 'PASS',
            livenessCheck: 'PASS'
          }
        };
      default:
        return { message: 'Test successful', timestamp: new Date().toISOString() };
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-2 space-y-6">
        <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="flex items-center space-x-2">
                  <TestTube className="w-5 h-5 text-blue-500" />
                  <span>API Testing Workspace</span>
                </CardTitle>
                <CardDescription>
                  Test your endpoints and validate responses
                </CardDescription>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <div className="w-2 h-2 bg-green-500 rounded-full mr-1"></div>
                  {session.environment}
                </Badge>
              </div>
            </div>
          </CardHeader>
          
          <CardContent>
            <Tabs defaultValue="test" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="test" className="flex items-center space-x-2">
                  <Play className="w-4 h-4" />
                  <span>Test Endpoint</span>
                </TabsTrigger>
                <TabsTrigger value="response" className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4" />
                  <span>View Response</span>
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="test" className="space-y-6 mt-6">
                <EndpointSelector
                  selectedEndpoint={selectedEndpoint}
                  onEndpointChange={setSelectedEndpoint}
                  completedTests={session.completedTests}
                />
                
                {selectedEndpoint && (
                  <PayloadEditor
                    endpoint={selectedEndpoint}
                    onTestRequest={handleTestRequest}
                    isLoading={isLoading}
                  />
                )}
              </TabsContent>
              
              <TabsContent value="response" className="mt-6">
                <ResponseViewer response={response} isLoading={isLoading} />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-6">
        <GoLiveChecklist
          completedTests={session.completedTests}
          onAdvanceStep={onAdvanceStep}
        />
      </div>
    </div>
  );
}